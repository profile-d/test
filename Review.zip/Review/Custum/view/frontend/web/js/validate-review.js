define([
    'jquery',
    'jquery/ui',
], function ($) {
    'use strict';
	$("submit").click(function(){
  
  var txtvalue=$("#nickname_field").val();
 
  if(isValid(txtvalue)){
            alert("Name can have only specific chras only.");
        }
        else{ alert("Accepted.");}
  });
    function isValid(str){
      return /[_@.!$%^#&+-{}=^~`,;]/g.test(str);
     
}
	
});